export 'package:escape_space/src/config.dart';
export 'package:escape_space/src/components/play_area.dart';