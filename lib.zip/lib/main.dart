import 'package:escape_space/escape_space.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(GameWidget(game: EscapeSpace()));
}
